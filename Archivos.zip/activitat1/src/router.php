<?php
/**
 * Returns url route
 */
function getRoute():string{
if(isset($RQUEST['url'])){
    $url=$_REQUEST['url'];
}else{
    $url='home';
}
switch($url){
    //ecceso a vista tpl
    case 'login';
    return 'login';
    case 'register';
    return 'register';
    //acceso a proceso login
    case 'login_action';
    return 'login_action';
    case 'register_action';
    return 'register_action';
    case 'logout';
    return 'logout';
    default:
    return 'home';
}
}