<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
</head>
<body>
    <header>
    <h1>Login</h1>
    </header>
    <main>
        <aside>
            <ul>
                <li>
                    <a href="?url=login">Login</a>
                </li>
                <li>
                    <a href="?url=register">Register</a>
                </li>
                <li>
                    <a href="?url=home">Home</a>
                </li>
            </ul>
        </aside>
    </main>
    <form action="?url=login_action" method="post">
    <input type="email" name="email" placeholder="Email">
    <input type="password" name="passwd" placeholder="Password">
    <button type="submit">Login</button>

    </form>

</body>
</html>