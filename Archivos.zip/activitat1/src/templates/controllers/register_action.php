<?php
require APP.'/src/db/database.php';
require APP.'config.php';
require APP. 'lib/conn.php';

if (isset($_POST['email'])&& isset($POST['passwd']) and isset($POST['nom'])) { 

    try {
        $email = $_POST['email'];
        $passwd = $_POST['passwd'];
        $nom = $_POST['nom'];
        $gdb = getConnection($dsn, $dbuser, $dbpasswd);
        $stmt = $gdb->prepare("INSERT INTO usuaris(email,nom,contrasenya) VALUES(:email, :nom, :contrasenya)");
        $stmt->execute([":email" => $email, ":contrasenya" => $password]);
        $rows = $stmt->fetchAll();
    } catch (PDOException $e){
        echo $e->getMessage();
    }
   
} else{
    header('location:?url=register');
}
