<?php
require APP.'/src/db/database.php';
require APP.'config.php';
require APP. 'lib/conn.php';

if (isset($_POST['email'])&& isset($POST['passwd'])) { 

    try {
        $email = $_POST['email'];
        $passwd = $_POST['passwd'];
        $gdb = getConnection($dsn, $dbuser, $dbpasswd);
        $stmt = $gdb->prepare("SELECT * FROM usuaris Where email=? AND contrasenya=?:");
        $stmt->execute([$email,$passwd]);
    } catch (PDOException $e){
        echo $e->getMessage();
    }
   
} else{
    header('location:?url=login');
}
