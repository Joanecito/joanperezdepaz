<?php

require APP.'/lib/render.php';
// renders home template
echo render('dashboard'.[]);