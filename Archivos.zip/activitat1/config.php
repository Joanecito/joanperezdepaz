<?php
//DATOS acceso a BBDD
define('APP',__DIR__);
$dbhost='localhost';
$dname='SCHOOL';
$dbuser='root';
$dbpasswd='nou_password';
$dsn='mysql:host='.$dbhost.';dbname='.$dbname.';charset=utf8mb4';