<?php
session_start();
session_destroy();
echo $_COOKIE['PHPSESSID'];
if(isset($_SESSION['user'])){
    echo $_SESSION['user'];
}else{
    echo 'anonimo';
}
echo $_SESSION['user'];
?>