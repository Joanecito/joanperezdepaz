<?php
session_start();
require 'config.php';
require 'src/router.php';
$controller=getRoute();
// var_dump($controller);
require APP.'/src/controllers'.$controller.'.php';