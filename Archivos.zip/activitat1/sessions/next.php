<?php
session_start();
$id=session_id();
echo $id .'<br>';
echo 'Hola '.$_SESSION['user'].'<br>';
echo '<a href="logout.php">SALIR</a>'

?>